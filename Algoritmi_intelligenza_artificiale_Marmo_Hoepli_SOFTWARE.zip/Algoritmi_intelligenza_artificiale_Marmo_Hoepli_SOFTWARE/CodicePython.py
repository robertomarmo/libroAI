"""
Codice Python presentato nel libro "Algoritmi per l'Intelligenza Artificiale"
scritto da Roberto Marmo per editore Hoepli
sito web https://www.algoritmiia.it/libro/  email ia@robertomarmo.net 
aggiornamento 30 maggio 2020
versione ridotta per motivi di copyright, per avere la versione intera
scrivere email a ia@robertomarmo.net 
"""

#-----------------------------------------------------------------------------------------
#Capitolo 5 Evolutionary algorithm
# scarica da repository GitHub
!git clone https://github.com/DEAP/deap.git
# installa libreria
!pip install deap
# importare librerie da usare
import random
from deap import base, creator, tools

creator.create("FitnessMax", base.Fitness, weights=(1.0,))
creator.create("Individual", list, fitness=creator.FitnessMax)


toolbox = base.Toolbox()
toolbox.register("attr_bool", random.randint, 0, 1)
toolbox.register("individual", tools.initRepeat, creator.Individual, 
    toolbox.attr_bool, 10)
toolbox.register("population", tools.initRepeat, list, toolbox.individual)

def evalOneMax(individual):
    return sum(individual),
toolbox.register("evaluate", evalOneMax)
toolbox.register("mate", tools.cxTwoPoint)
toolbox.register("mutate", tools.mutFlipBit, indpb=0.05)
toolbox.register("select", tools.selTournament, tournsize=3)

def main():
    random.seed(64)

    n=50
    pop = toolbox.population(n)

    CXPB, MUTPB = 0.5, 0.2
    
    fitnesses = list(map(toolbox.evaluate, pop))
    for ind, fit in zip(pop, fitnesses):
        ind.fitness.values = fit
    
    print("  Valutazione %i individui" % len(pop))

    fits = [ind.fitness.values[0] for ind in pop]
    g = 0

    print("Gen.  non-valide Min Mas Media Std \n")    
    while max(fits) < 10 and g < 100:

        g = g + 1

        offspring = toolbox.select(pop, len(pop))
        offspring = list(map(toolbox.clone, offspring))
    
        for child1, child2 in zip(offspring[::2], offspring[1::2]):

            if random.random() < CXPB:
                toolbox.mate(child1, child2)

                del child1.fitness.values
                del child2.fitness.values

        for mutant in offspring:

            if random.random() < MUTPB:
                toolbox.mutate(mutant)
                del mutant.fitness.values
    
        invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
        fitnesses = map(toolbox.evaluate, invalid_ind)
        for ind, fit in zip(invalid_ind, fitnesses):
            ind.fitness.values = fit

        pop[:] = offspring
        
        fits = [ind.fitness.values[0] for ind in pop]
        
        length = len(pop)
        mean = sum(fits) / length
        sum2 = sum(x*x for x in fits)
        std = abs(sum2 / length - mean**2)**0.5

        print("%4d %3d %2d %2d %0.3f %0.3f" % (g, len(invalid_ind), min(fits), max(fits), mean, std))

    print("-- Fine dell'evoluzione --")
    
    best_ind = tools.selBest(pop, 1)[0]
    print("Individuo %s con prestazione migliore  %s" % (best_ind, best_ind.fitness.values))


#per fare eseguire il codice
if __name__ == "__main__":
    main()
	
	
#-----------------------------------------------------------------------------------------
#CAPITOLO 6  Expert system
!pip install experta

from random import choice  #per generare scelte casuali
from experta import * #per realizzare il sistema esperto

class Luce(Fact):
    """Informazione sulla luce del semaforo"""
    pass

class Semaforo(KnowledgeEngine):
#definizione delle regole di calcolo
    @Rule(Luce(colore='verde'))
    def luce_verde(self):
        print ("Passare")

    @Rule(Luce(colore='rosso'))
    def luce_rossa(self):
        print ("Non passare") 

    @Rule(AS.Luce << Luce(colore=L('giallo') | L('giallo lampeggia')))
    def attenzione(self, light):
        print ("Attenzione al ", Luce["colore"]) 

engine = Semaforo() #scelta del sistema esperto
engine.reset()
engine.declare(Luce(colore=choice(['verde', 'giallo', 'giallo lampeggia', 'rosso']))) #si sceglie un colore a caso, il sistema esperto dice la risposta con le regole impostate
engine.run()


from experta import *

class Persona(Fact):
    """Informazioni sulla persona da analizzare"""
    pass

	#per contare quanti sintomi reali bisogna considerare
def conteggio(p, *fields):
    return sum([p.get(x, 0) for x in fields])

class AnalisiDiabete(KnowledgeEngine):
    @Rule(Persona(eta=MATCH.eta))
    def persona_maggiorenne(self, eta):
        if eta >= 18:
            self.declare(Fact(maggiorenne=True))
        else:
            self.declare(Fact(maggiorenne=False))
            print("ATTENZIONE per i minorenni usare un altro sistema")

    @Rule(Fact(maggiorenne=True), Persona(glicemia=MATCH.glicemia))
    def iper_glicemia(self, glicemia):
        if glicemia > 110:
            self.declare(Fact(rischio_iperglicemia=True))
            print("Glicemia sopra la soglia")
        else:
            self.declare(Fact(rischio_iperglicemia=False))

    @Rule(Fact(maggiorenne=True), Persona(glicemia=MATCH.glicemia))
    def normo_glicemia(self, glicemia):
        if (glicemia > 70) and (glicemia < 110):
            print("Glicemia nella norma")
            self.declare(Fact(normo_glicemia=True))
        else:
            self.declare(Fact(normo_glicemia=False))

    @Rule(Fact(maggiorenne=True), Persona(glicemia=MATCH.glicemia))
    def ipo_glicemia(self, glicemia):
        if glicemia < 70:
            print("Glicemia sotto la soglia")
            self.declare(Fact(rischio_ipoglicemia=True))
        else:
            self.declare(Fact(rischio_ipoglicemia=False))

    #se utente � maggiorenne conto i sintomi dell'avere poco zucchero, esistere almeno 2 sintomi
    
    @Rule(Fact(maggiorenne=True),
          AS.p << Persona(),
          TEST(lambda p: conteggio(p,
                                'fame_insaziabile',
                                'mal_di_testa',
                                'sudorazione',
                                'tremore_alla_mano',
                                'volto_pallido') > 2))
    def poco_zucchero(self, p):
        self.declare(Fact(poco_zucchero=True))

    #se utente � maggiorenne e ci sono segnali di poco zucchero nel sangue
    @Rule(Fact(maggiorenne=True),
          Fact(parenti_diabetici=True),
          Fact(poco_zucchero=True))
    def rischio_basso(self):
        print("Attenzione, il paziente potrebbe essere diabetico")

    #se utente � maggiorenne e ci sono segnali di poco zucchero nel sangue e glicemia sotto soglia
    @Rule(Fact(maggiorenne=True),
          Fact(rischio_ipoglicemia=True),
          Fact(poco_zucchero=True))
    def allarme_basso(self):
        print("Pericolo! Alto rischio di diabete, visitare da specialista")

    #se utente � maggiorenne e ha parenti con diabete
    @Rule(Fact(maggiorenne=True),
          Persona(parentela_diabetica=True))
    def parenti_diabetici(self):
        self.declare(Fact(parenti_diabetici=True))

    #se utente � maggiorenne conto i sintomi dell'avere troppo zucchero, esistere almeno 2 sintomi
    @Rule(Fact(maggiorenne=True),
          AS.p << Persona(),
          TEST(lambda p: conteggio(p,
                                    'bocca_asciutta',
                                    'formicolio_mani_piedi'
                                    'lenta_guarigione_ferite',
                                    'mal_di_testa',
                                    'sete_frequente',
                                    'vista_offuscata',
                                    'urina_spesso',) > 2)
    )
    def troppo_zucchero(self, **_):
        self.declare(Fact(troppo_zucchero=True))

    @Rule(Fact(maggiorenne=True),
          Fact(parenti_diabetici=True),
          Fact(troppo_zucchero=True))
    def rischio_alto(self):
        print("Attenzione, il paziente potrebbe essere diabetico")

    @Rule(Fact(maggiorenne=True),
          Fact(rischio_iperglicemia=True),
          Fact(troppo_zucchero=True))
    def allerta_alto(self):
        print("Pericolo! Alto rischio di diabete, visitare da specialista")


engine = AnalisiDiabete() #attiva il sistema esperto
engine.reset()
#dichiarazione di eta, analisi glicemia e sintomi in ordine alfabetico per migliorare leggibilit�
engine.declare(Persona(eta=29,
                        glicemia=80,
                        bocca_asciutta= False,
                        fame_insaziabile= True,
                        formicolio_mani_iedi= True,
                        lenta_guarigione_ferite= False,
                        mal_di_testa= True,
                        sete_frequente= True,
                        sudorazione= True,
                        tremore_alla_mano= False,
                        volto_pallido= False,
                        vista_offuscata= False,
                        urina_spesso= False ))
engine.run()



#-----------------------------------------------------------------------------------------
#Capitolo 7 Fuzzy logic

#installazione della libreria fuzzy-c-means
!git clone https://github.com/omadson/fuzzy-c-means.git
!pip install fuzzy-c-means

from fcmeans import FCM 
#carica la funzione per fare algoritmo fuzzy clustering
from sklearn.datasets import make_blobs 
#carica i dati di esempio da libreria per apprendimento automatico
from matplotlib import pyplot as plt 
#carica la libreria per la creazione di grafici
from seaborn import scatterplot as scatter
#carica la funzione per fare scatter plot, grafico a dispersione in cui due variabili di un set di dati sono riportate su uno spazio cartesiano

n_samples = 50000 #numero di oggetti da classificare
n_bins = 3  # 3 classi in cui classificare
centers = [(-5, -5), (0, 0), (5, 5)] 
#centri delle classi
X,_ = make_blobs(n_samples=n_samples, n_features=2, cluster_std=1.0,centers=centers, shuffle=False, random_state=42)
#creazione di grande gruppo contenente gli oggetti da classificare intorno ai 3 centri

#esecuzione del fuzzy-c-means
fcm = FCM(n_clusters=n_bins)
fcm.fit(X)

#generazione centri dei gruppi ottenuti output
fcm_centers = fcm.centers
fcm_labels  = fcm.u.argmax(axis=1)

#creazione dei grafici
%matplotlib inline
f, axes = plt.subplots(1, 2, figsize=(11,5))
scatter(X[:,0], X[:,1], ax=axes[0])
scatter(X[:,0], X[:,1], ax=axes[1], hue=fcm_labels)
scatter(fcm_centers[:,0], fcm_centers[:,1], ax=axes[1],marker="s",s=200)
plt.show()


#-----------------------------------------------------------------------------------------
#Capitolo 10 Machine learning

#semplice esempio
#importazione librerie necessarie
import numpy as np
from sklearn import datasets #riferimento ai dati di esempio
from sklearn.model_selection import train_test_split #organizza dati learning
from sklearn.linear_model import Perceptron #modello di predizione scelto
from sklearn.metrics import accuracy_score #calcolo dell'accuratezza

#carica gli specifici dati Iris
iris = datasets.load_iris()
X = iris.data #input
y = iris.target #output
#divide in insiemi di training 80% e test 20% senza scelta casuale 
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

#impostazione parametri del modello neural network Perceptron
ppn = Perceptron(max_iter=40, tol=0.001, eta0=0.01, random_state=0)
#supervised learning del modello scelto
ppn.fit(X_train, y_train)

#predizione sul test set
y_pred = ppn.predict(X_test)
#verifica errore sul test set
accuracy_score(y_test, y_pred)

#messa in esercizio su nuovi dati di un oggetto da classificare
print ("classe predetta",ppn.predict([[5.8, 1.8, 4.1, 2.4]]))



#-----------------------------------------------------------------------------------------
#Capitolo 9 Pre-elaborazione dei dati

import numpy as np
c = np.array([1, 2, np.NAN, 3, 4])
print("Dati caricati:",c)
print("Test su presenta NaN:",np.isnan(c))
print("Dati caricati senza NaN:",c[~np.isnan(c)])
print("Media dei dati caricati con NaN:",np.mean(c))
print("Media dei dati caricati senza NaN:",np.mean(c[~np.isnan(c)]))

#esempio di ispezione per conoscere il dataset
#caricamento dati e librerie
from sklearn.datasets import load_iris
import pandas as pd
iris = load_iris()
print("Descrizione dataset Iris",iris.data.shape)
print("\nQuantit� di righe:",iris.target.shape)
print("\nChiavi:",iris.keys())
print("\nDimensioni:",iris.data.shape)	
print("\nNomi feature:",iris.feature_names)
print("\nDescrizione:",iris.DESCR)

iris_pd = pd.DataFrame(iris.data)
print("\nDati nelle prime 5 righe")
print(iris_pd.head())

iris_pd.columns = iris.feature_names
print("\nDati nelle prime 5 righe con nomi feature su colonne\n",iris_pd.head())

print("\nPrincipali statistiche sui dati contenuti\n",iris_pd.describe())

# prepara librerie
import matplotlib.pyplot as plt
import seaborn as sns

#carica dataset Iris da sns
iris = sns.load_dataset("iris")
iris.head()

#grafico della relazione di ogni feature con altre specie
plt.xlabel('Features')
plt.ylabel('Specie')
pltX = iris.loc[:, 'sepal_length']
pltY = iris.loc[:,'species']
plt.scatter(pltX, pltY, color='blue', label='sepal_length', marker=".")
pltX = iris.loc[:, 'sepal_width']
pltY = iris.loc[:,'species']
plt.scatter(pltX, pltY, color='green', label='sepal_width', marker="s")
pltX = iris.loc[:, 'petal_length']
pltY = iris.loc[:,'species']
plt.scatter(pltX, pltY, color='red', label='petal_length', marker="p")
pltX = iris.loc[:, 'petal_width']
pltY = iris.loc[:,'species']
plt.scatter(pltX, pltY, color='black', label='petal_width', marker="x")
plt.legend(loc=4, prop={'size':8})
plt.show()



#-----------------------------------------------------------------------------------------
#Capitolo 10 Valutazione modello


from sklearn.metrics import mean_absolute_error
y_true = [3, -0.5, 2, 7]
y_pred = [2.5, 0.0, 2, 8]
print(mean_absolute_error(y_true, y_pred))

y_true = [[0.5, 1], [-1, 1], [7, -6]]
y_pred = [[0, 2], [-1, 2], [8, -5]]
print(mean_absolute_error(y_true, y_pred))

from sklearn.metrics import mean_squared_error
y_true = [3, -0.5, 2, 7]
y_pred = [2.5, 0.0, 2, 8]
print(mean_squared_error(y_true, y_pred))

y_true = [[0.5, 1],[-1, 1],[7, -6]]
y_pred = [[0, 2],[-1, 2],[8, -5]]
print(mean_squared_error(y_true, y_pred))



from sklearn.metrics import mean_squared_error
from math import sqrt
y_true = [3, -0.5, 2, 7]
y_pred = [2.5, 0.0, 2, 8]
print(sqrt(mean_squared_error(y_true, y_pred)))

y_true = [[0.5, 1],[-1, 1],[7, -6]]
y_pred = [[0, 2],[-1, 2],[8, -5]]
print(sqrt(mean_squared_error(y_true, y_pred)))

from sklearn.metrics import r2_score
y_true = [3, -0.5, 2, 7]
y_pred = [2.5, 0.0, 2, 8]
print(r2_score(y_true, y_pred))

y_true = [[0.5, 1], [-1, 1], [7, -6]]
y_pred = [[0, 2], [-1, 2], [8, -5]]
print(r2_score(y_true, y_pred))

from sklearn.metrics import log_loss
print(log_loss(["spam", "no spam", "no spam", "spam"],[[.0, 1.0], [1.0, .0], [1.0, .0], [.0, 1.0]])) #tutto corretto
print(log_loss(["spam", "no spam", "no spam", "spam"],[[.1, .9], [.9, .1], [.9, .1], [.1, .9]])) #valore un poco basso ma corretto
print(log_loss(["spam", "no spam", "no spam", "spam"],[[.1, .9], [.9, .1], [.8, .2], [.45, .55]])) #un basso e un quasi indeciso
print(log_loss(["spam", "no spam", "no spam", "spam"],[[.5, .5], [.5, .5], [.5, .5], [.5, .5]])) #tutti indecisi
print(log_loss(["spam", "no spam", "no spam", "spam"],[[1.0, .0], [.0, 1.0], [.0, 1.0], [1.0, .0]])) #tutto sbagliato

# classi individuate con numeri
from sklearn.metrics import confusion_matrix
y_true = [2, 0, 2, 2, 0, 1]
y_pred = [0, 0, 2, 2, 0, 2]
print("Classi con numeri\n", confusion_matrix(y_true, y_pred))

# classi individuate con etichette
y_true = ["cat", "ant", "cat", "cat", "ant", "bird"]
y_pred = ["ant", "ant", "cat", "cat", "ant", "cat"]
print("Classi con etichette\n", confusion_matrix(y_true, y_pred, labels=["ant", "bird", "cat"]))

#classificatore binario e calcolo metriche da matrice confusione
print("Classificatore binario\n", confusion_matrix([0, 1, 0, 1], [1, 1, 1, 0]))
tn, fp, fn, tp = confusion_matrix([0, 1, 0, 1], [1, 1, 1, 0]).ravel()
print("Metriche da classificatore binario", tn, fp, fn, tp)


#-----------------------------------------------------------------------------------------
#Capitolo 11 k-NEAREST NEIGHBORS


#librerie necessarie
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

#prepara training e test set di Iris
iris = datasets.load_iris()
X, y = iris.data, iris.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

#prova con diversi valori di k e scelta dei pesi
scores_list=[]
for k in range(1, 5): #da 0 a 3
   #fornire: iperparametro k, tipi di pesi da usare uniform distance, algoritmo da usare 
   kNN = KNeighborsClassifier(n_neighbors=k, weights='uniform', algorithm = 'auto')
   kNN.fit(X_train, y_train) #apprendimento training set
   scores=kNN.score(X_test, y_test) #accuratezza su test set
   scores_list.append(scores)
   print ("%d-NN accuratezza: %0.2f" % (k, scores.mean()))

#messa in esercizio prova su nuovo input
k=3 #scegliere il parametro k
kNN = KNeighborsClassifier(n_neighbors=k, weights='uniform', algorithm = 'auto')
kNN.fit(X_train, y_train) 
#ri-training set solo una volta per prepararlo con k scelto
new=[5.0, 2.0, 5.0, 2.0]
print("Input ", new)
print("Output probabilit� ", kNN.predict_proba([new]))
print("Output indice classe predetta ", kNN.predict([new]))
print("Distanza e indici punti vicini ", kNN.kneighbors([new]))


import matplotlib.pyplot as plt
plt.title('Relazione tra k e accuratezza')
plt.plot(range(1, 5), scores_list)
plt.xlabel('k'); plt.ylabel('Accuratezza');
plt.show()

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from sklearn import neighbors, datasets

k = 5 #iperparametro

#prepara training e test set di Iris
iris = datasets.load_iris()

#scelta prime due feature per fare grafico bidimensionale
X = iris.data[:, :2]
y = iris.target

h = .02  # step nella creazione di mesh grafica

#mappe di colore da usare
cmap_light = ListedColormap(['#FFAAAA', '#AAFFAA', '#AAAAFF'])
cmap_bold = ListedColormap(['#FF0000', '#00FF00', '#0000FF'])
#cmap_light = ListedColormap(['orange', 'cyan', 'cornflowerblue'])
#cmap_bold = ListedColormap(['darkorange', 'c', 'darkblue'])
weight='distance'
#prepara il modello e apprendimento
kNN = KNeighborsClassifier(k, weights='distance')
kNN.fit(X, y)

# disegno delle linee di confine (decision boundary) e assegna colore del punto
# appartenente alla zona colorata con mesh [x_min, x_max]x[y_min, y_max].
x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
xx, yy = np.meshgrid(np.arange(x_min, x_max, h), np.arange(y_min, y_max, h))
Z = kNN.predict(np.c_[xx.ravel(), yy.ravel()])

# crea il grafico
Z = Z.reshape(xx.shape)
plt.figure(); plt.pcolormesh(xx, yy, Z, cmap=cmap_light)

# inserisce i punti del training
plt.scatter(X[:, 0], X[:, 1], c=y, cmap=cmap_bold, s=25, edgecolor='k')
plt.xlim(xx.min(), xx.max()); plt.ylim(yy.min(), yy.max())
plt.title("Classificazione Iris con %i-NN e weights = 'distance'" % k)
plt.xlabel('Lunghezza sepalo (cm)'); plt.ylabel('Larghezza sepalo (cm)')
plt.text(4, 5, "setosa"); plt.text(8, 5, "virginica"); plt.text(5, 1.5, "versicolor")
plt.show() #mostra il grafico finale




# prepara librerie
from sklearn.datasets import load_iris 
from sklearn.model_selection import train_test_split 
from sklearn.neighbors import KNeighborsClassifier

# carica dataset
iris = load_iris()
X = iris.data
y = iris.target
# prepara training e test set con random_state=4 per la scelta casuale
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=4)
# crea KNN con n_neighbors = 5
knn = KNeighborsClassifier(n_neighbors = 5)
# il modello apprende
knn.fit(X_train, y_train)
# predizione valori per X_test test set
y_pred = knn.predict(X_test)
print('Accuratezza: ', knn.score(X_test, y_test))

# prepara libreria per k-folder
from sklearn.model_selection import cross_val_score
# usa il modello preparato prima
knn = KNeighborsClassifier(n_neighbors = 5)
# X,y divisi in 5 folder, scoring basato su accuratezza 
scores = cross_val_score(knn, X, y, cv=5, scoring='accuracy')
print("Score :", scores)

# media su cv punteggi per ottenere un punteggio di precisione
print("Media score: ", scores.mean())

import matplotlib.pyplot as plt 
# %matplotlib inline

k_range = range(1, 31)  #intervallo per valori di k
k_scores = []
for k in k_range: #calcolo modello con valori di k
    knn = KNeighborsClassifier(n_neighbors=k)
    scores = cross_val_score(knn, X, y, cv=5, scoring='accuracy')
    k_scores.append(scores.mean())#prepara dati per il grafico
plt.plot(k_range, k_scores)
plt.xlabel('Valore di K per K-NN')
plt.ylabel('Cross-Validated accuratezza')
plt.show()

#-----------------------------------------------------------------------------------------
#Capitolo 12 Linear regression


import matplotlib.pyplot as plt
import numpy as np
import math
linear_curve = lambda x: 2*x+1      
x_values = np.linspace(-4, 4, 100)
y_values = linear_curve(x_values)
plt.plot(x_values, y_values)
plt.gca().xaxis.grid(True)
plt.ylabel('y'); plt.xlabel('x')

import numpy as np

import matplotlib.pyplot as plt
import numpy as np
from sklearn import datasets, linear_model
from sklearn.metrics import mean_squared_error, r2_score

#carica il dataset sul diabete
diabetes_X, diabetes_y = datasets.load_diabetes(return_X_y=True)

# sceglie solo una feature
diabetes_X = diabetes_X[:, np.newaxis, 2]

#divisione input e output in training e test set
diabetes_X_train = diabetes_X[:-20]
diabetes_X_test = diabetes_X[-20:]
diabetes_y_train = diabetes_y[:-20]
diabetes_y_test = diabetes_y[-20:]

# crea il modello linear logistic
regr = linear_model.LinearRegression()

# esegue l'apprendimento
regr.fit(diabetes_X_train, diabetes_y_train)

# predizione su dati del test set
diabetes_y_pred = regr.predict(diabetes_X_test)

print('Coefficienti usati: ', regr.coef_)
print('Mean Squared Error: %.2f'% mean_squared_error(diabetes_y_test, diabetes_y_pred))
print('Coefficient of determination: %.2f'% r2_score(diabetes_y_test, diabetes_y_pred))
# se coefficient of determination � 1 indica predizione perfetta

# crea il grafico di funzione lineare
plt.scatter(diabetes_X_test, diabetes_y_test,  color='black') #punti
plt.plot(diabetes_X_test, diabetes_y_pred, color='blue', linewidth=3) #retta
plt.xlabel('x'); plt.ylabel('y')
plt.show()

# crea il grafico residual plot dell'errore
plt.scatter(regr.predict(diabetes_X_train), regr.predict(diabetes_X_train)-diabetes_y_train, c='b', marker='.', s=40)
plt.scatter(regr.predict(diabetes_X_test), regr.predict(diabetes_X_test)-diabetes_y_test, c='r', marker='+',  s=40)
plt.hlines(y=0, xmin=0,xmax=350)
plt.title('Residual Plot errore dati training (.) e test (+)')
plt.ylabel('Errore Residuale'); plt.xlabel('Predizione')

from sklearn.datasets import load_boston
import pandas as pd

boston = load_boston() #carica dataset

# organizza dataframe
boston_pd = pd.DataFrame(boston.data) #prende dati
boston_pd.columns = boston.feature_names #aggiunge nomi colonne

boston_pd['PRICE'] = boston.target #aggiunge colonna prezzo da predire
print(boston_pd.head()) #visualizza le prime 5 righe

from sklearn.model_selection import train_test_split
#prerara insieme feature X e risultato corrispondente Y
X = boston_pd.drop('PRICE', axis = 1)
y = boston_pd['PRICE']
#organizza i dati in training e test set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.33, random_state = 5)

from sklearn.linear_model import LinearRegression
lm = LinearRegression() #crea modello
lm.fit(X_train, Y_train) #apprendimento

Y_pred = lm.predict(X_test) #predizione su test set

#crea grafico
plt.scatter(Y_test, Y_pred)
plt.xlabel("Prezzo reale: $Y_i$")
plt.ylabel("Prezzo da predizione: $\hat{Y}_i$")
plt.title("Prezzi reali vs predetti: $Y_i$ vs $\hat{Y}_i$")

from sklearn.metrics import mean_squared_error
mse = mean_squared_error(Y_test, Y_pred)
print("Mean Squared Error",mse)

#-----------------------------------------------------------------------------------------
#Capitolo 13 Logistic regression

import matplotlib.pyplot as plt
import numpy as np
import math
lgs_curve = lambda x: 1/(1 + math.e**(-(x)))         
x_values = np.linspace(-8, 8, 100)
y_values = lgs_curve(x_values)
plt.plot(x_values, y_values)
plt.gca().xaxis.grid(True)
plt.ylabel('y'); plt.xlabel('x')

import numpy as np

data = np.loadtxt('fraud_data.csv', delimiter=',',skiprows=1) 
X = data[:,:-1] # tutte le feature, da colonna 0 alla penultima
y = data[:,-1] # classificazione, solo ultima colonna

from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.25,random_state=0)

# prepara il modello
from sklearn.linear_model import LogisticRegression
logreg = LogisticRegression()

# training
logreg.fit(X_train,y_train)

# predizione su dati di test
y_pred=logreg.predict(X_test)
print("Predizione", y_pred)

from sklearn import metrics
cnf_matrix = metrics.confusion_matrix(y_test, y_pred)
print("Matrice di confusione \n", cnf_matrix)

# Import the dependencies
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

#carica il dataset
data = sns.load_dataset("iris")
data.head()

X = data.iloc[:, :-1] #selezione colonne con feature
y = data.iloc[:, -1] #etichette di classi in ultima colonna

#80% training e 20% test
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

#training del modello
model = LogisticRegression()
model.fit(x_train, y_train)

#predizione con dati test
predictions = model.predict(x_test)
print("Predizione: ",predictions)

#-----------------------------------------------------------------------------------------
#Capitolo 14 Support Vector Machine

#prepara librerie
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import datasets
from sklearn import svm

#crea dataset
X, y = datasets.load_iris(return_X_y=True)

#organizza training e test set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, random_state=0)

print(X.shape, y.shape, X_train.shape, y_train.shape, X_test.shape, y_test.shape)

#prepara  modello con  divisione dataset in training e test set
clf = svm.SVC(kernel='linear', C=1).fit(X_train, y_train)
print("Score :", clf.score(X_test, y_test))

#uso di cross validation
from sklearn.model_selection import cross_val_score
clf = svm.SVC(kernel='linear', C=1)
scores = cross_val_score(clf, X, y, cv=5) # 5 folder
print("Accuratezza cross validation: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))

#-----------------------------------------------------------------------------------------
#Capitolo 15 Decision tree


# classificazione Iris
import pandas as pd
from sklearn.datasets import load_iris
from sklearn import tree

# carica dataset e prepara i dataframe per il training
iris = load_iris()
X = pd.DataFrame(iris.data[:, :], columns = iris.feature_names[:])
y = pd.DataFrame(iris.target, columns =["Species"])

# crea il modello
dtree = tree.DecisionTreeClassifier(max_depth = 2)
dtree.fit(X,y)

print ("Classe:",dtree.predict([[5.1,	3.5,	1.4,	0.2]])) #classe vincente
print ("Probabilit�:",dtree.predict_proba([[5.1,	3.5,	1.4,	0.2]])) #probabilit� assegnate
tree.plot_tree(dtree.fit(X,y),filled='true')
#rappresentazione semplice del decision tree, con testo e grafico colorato

import graphviz  #libreria con varie possibilit� grafiche
dot_data = tree.export_graphviz(dtree, out_file=None, 
                     feature_names=iris.feature_names, class_names=iris.target_names,  
                     filled=True, rounded=True, special_characters=True)
graph = graphviz.Source(dot_data)
graph #rappresentazione grafica del decision tree

# in Google CoLab mettere in altra cella ed eseguirla dopo il grafico
graph.render("decision tree iris")
#crea un file formato PDF con la rappresentazione grafica

from sklearn.tree.export import export_text
r = export_text(dtree, feature_names=iris['feature_names'])
print(r) #rappresentazione del decision tree con testo

import numpy as np
import matplotlib.pyplot as plt

from sklearn.datasets import load_iris
from sklearn.tree import DecisionTreeClassifier, plot_tree

n_classes = 3
plot_colors = "ryb"
plot_step = 0.02

iris = load_iris()

for pairidx, pair in enumerate([[0, 1], [0, 2], [0, 3],
                                [1, 2], [1, 3], [2, 3]]):
    # prepara coppia di feature
    X = iris.data[:, pair]
    y = iris.target

    # training
    dtree = DecisionTreeClassifier().fit(X, y)

    # disegna decision boundary
    plt.subplot(2, 3, pairidx + 1)

    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, plot_step),
                         np.arange(y_min, y_max, plot_step))
    plt.tight_layout(h_pad=0.5, w_pad=0.5, pad=2.5)

    Z = dtree.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    cs = plt.contourf(xx, yy, Z, cmap=plt.cm.RdYlBu)

    plt.xlabel(iris.feature_names[pair[0]])
    plt.ylabel(iris.feature_names[pair[1]])
    mark =['+','s','.']
    # disegna i punti nel grafico
    for i, color in zip(range(n_classes), plot_colors):
        idx = np.where(y == i)
        plt.scatter(X[idx, 0], X[idx, 1], c=color, label=iris.target_names[i], marker=mark[i], 
                    cmap=plt.cm.RdYlBu, edgecolor='black', s=15)

plt.suptitle("Decision Tree su coppie di feature Iris")
plt.legend(loc='upper left', bbox_to_anchor=(1, 0.5))
plt.axis("tight")



#-----------------------------------------------------------------------------------------
#Capitolo 16 Bayes e naive Bayes

!git clone https://github.com/pgmpy/pgmpy.git
!pip install pgmpy # carica libreria

#prepara importazioni necessarie
from pgmpy.models import BayesianModel
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination
import numpy as np

BNMod = BayesianModel()
BNMod.add_node("ML")
BNMod.add_node("US")
BNMod.add_node("CC")
BNMod.add_node("GS")
BNMod.add_node("SU")

BNMod.add_edge("ML", "CC")
BNMod.add_edge("US", "CC")
BNMod.add_edge("GS", "CC")
BNMod.add_edge("GS", "SU")
BNMod.add_edge("CC", "SU")

#aggiunge le tabelle con probabilit�, prima caso Falso poi Vero, somma riga=1
#crea nodi radice
cpd_ML = TabularCPD('ML', 2, values=[[.90], [.10]]) 
cpd_US = TabularCPD('US', 2, values=[[.80], [.20]])
cpd_GS = TabularCPD('GS', 2, values=[[.85], [.15]])

#crea nodi figlio
cpd_SU = TabularCPD('SU', 2, values=[[0.95, .85, .90, .60], [.05, .15, .10, .40]],
                   evidence=['CC', 'GS'], evidence_card=[2, 2])
cpd_CC = TabularCPD('CC', 2,
                   values=[[0.95, .85, .95, .80, .25, .15, .10, .05], [.05, .15, .05, .20, .75, .85, .90, .95]],
                   evidence=['ML', 'GS', 'US'], evidence_card=[2, 2,2])
BNMod.add_cpds(cpd_ML, cpd_US, cpd_GS, cpd_SU, cpd_CC) #aggiunge le tabelle

BNMod.check_model(); print("Il modello risulta corretto.")

#realizza le inferenze
solver = VariableElimination(BNMod)

print("Dipendenze tra le variabili\n", BNMod.get_independencies())

#inferenza su nodo CC
result1 = solver.query(variables=['CC'])
print("Probabilit� su CC casi Falso e Vero", result1.values) 
#inferenza su nodo CC dato che ML � vero
result2 = solver.query(variables=['CC'], evidence={'ML': 1})
print("Probabilit� su CC dato che ML � vero", result2.values[1])

#-----------------------------------------------------------------------------------------
#Capitolo 17 Neural network

#Perceptron
# carica librerie
from sklearn import datasets
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Perceptron
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import numpy as np

# carica Iris dataset e prepara i dati per training
iris = datasets.load_iris()
X = iris.data
y = iris.target

# divisione dataset in 70% training set e 30% test set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)

# prepara StandardScaler e trasforma dati X per avere media 0 e varianza 1
sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)

# crea Perceptron con 40 iterazioni (epoche), 0.001 tolleranza sufficiente per l'uscita, learning rate  0.1
# genera pesi casuali nei pesi iniziali, verbosit� per stampare cosa calcola
ppn = Perceptron(max_iter=40, tol=0.001, eta0=0.1, random_state=1, verbose=10)

print("\nTipo: ",type(ppn))

# training del Perceptron
ppn.fit(X_train_std, y_train)

print("\nDizionario attributi con parametri di Perceptron: \n",ppn.__dict__)
print("\nValori dei pesi dopo training:\n", ppn.coef_)
print("\nValori dei bias dopo training:\n", ppn.intercept_)

# predizione del Perceptron per test set e indici di prestazione
y_pred = ppn.predict(X_test_std)
print("\nRisultati sul test set:\n",y_pred)
print("\nValori corretti del test set:\n",y_test)
print("\nAccuracy: %.2f" % accuracy_score(y_test, y_pred))
print("\nConfusion Matrix:\n",confusion_matrix(y_test,y_pred))
print("\nRiepilogo classificazione:\n",classification_report(y_test,y_pred))
print("\nRighe test set solo per output con classe 1\n", X_test[y_pred==1])

#salva nel file l'oggetto con valori ottimizzati ottenuti dal training
import pickle #vedere https://docs.python.org/3/library/pickle.html
with open("perceptron.pkl", "wb") as f:
    pickle.dump(ppn,f, pickle.HIGHEST_PROTOCOL)

#salva i valori dei pesi in file CSV
numpy.savetxt("PPNcoef.csv", ppn.coef_, delimiter=",")
numpy.savetxt("PPNintercept.csv", ppn.intercept_, delimiter=",")

#esempio messa in esercizio di Perceptron preparato precedentemente
import pickle 
with open("perceptron.pkl", "rb") as f:
    ppn = pickle.load(f)

# Load required libraries
from sklearn import datasets
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
import numpy as np

#crea nuovi valori non ancora usati
X_test = [[5.2, 2.7, 3.9, 1.4],
 [4.9, 2.4, 3.3, 1. ],
 [5.5, 2.6, 4.4, 1.2],
 [6.3, 3.3, 6.0, 2.5],
 [4.6, 3.4, 1.4, 0.3]]

#ripete operazione di trasformazione creata nel training
sc = StandardScaler()
sc.fit(X_test) 
X_test_std = sc.transform(X_test)


# predizione su valori nuovi
y_pred = ppn.predict(X_test_std) 
print("Predizione con specifiche Perceptron caricato da file",y_pred)
for value in X_test_std:
    pred = ppn.predict([value])
    print(pred)

"""MLP"""

# MLP
# carica librerie
from sklearn import datasets
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import numpy as np
import matplotlib.pyplot as plt

# carica dataset iris
iris = datasets.load_iris()

# crea dati X con feature e y con laclasse associata
X = iris.data
y = iris.target

# divisione dati in 70% per training set e 30% per test set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)

#prepara StandardScaler e trasforma dati X per avere media 0 e varianza 1
sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)

#crea MLP con 10 neuroni nello strato hidden, 40 iterazioni, correzione alpha
#metodo di calcolo adam, nessuna descrizione dei calcoli, tolleranza nel risultato,
#generazione causale dei pesi, learning rate per regolare cambiamento pesi, nessun early stopping
mlp = MLPClassifier(hidden_layer_sizes=(10,), max_iter=40, alpha=1e-4,
                    solver='adam', verbose=0, tol=1e-8, random_state=1,
                    learning_rate_init=.01, early_stopping=False)

print("\nTipo \n",type(mlp))

# training di MLP
mlp.fit(X_train_std, y_train)

print("\nDizionario attributi con parametri di MLP: \n",mlp.__dict__)
print("\nValori dei pesi dopo training:\n", mlp.coefs_)
print("\nValori dei bias dopo training:\n", mlp.intercepts_)

# predizione per calcolare la risposta su test set
y_pred = mlp.predict(X_test_std)
print("\nRisultati sul test set:\n",y_pred)


print("\nValori corretti del test set:\n",y_test)
print("\nAccuracy: %.2f" % accuracy_score(y_test, y_pred))

print("\nConfusion Matrix:\n",confusion_matrix(y_test,y_pred))
print("\nRiepilogo della classificazione:\n",classification_report(y_test,y_pred))

print("\nRighe test set solo per output con classe 1\n", X_test[y_pred==1])

plt.plot(mlp.loss_curve_, color='green', alpha=0.8, label='Train')
plt.title("Loss curve over epochs", fontsize=14)
plt.xlabel('Numero di iterazioni'), plt.ylabel('Loss Function')
plt.legend(loc='upper right')
plt.show()

print("Elenco dati loss",mlp.loss_curve_)
print("Valore minore di loss:",mlp.best_loss_)

print(y_pred)
print("\nValori dei pesi dopo training:\n", mlp.coefs_)
print("\nValori dei bias dopo training:\n", mlp.intercepts_)


#-----------------------------------------------------------------------------------------
#Capitolo 18 Deep Neural Network
#crea un piccolo tensore
from numpy import array
T = array([
  [[1,2,3],    [4,5,6],    [7,8,9]],
  [[11,12,13], [14,15,16], [17,18,19]],
  [[21,22,23], [24,25,26], [27,28,29]],
  ])
print(T.shape)
print(T)



%tensorflow_version 2.x #attiva esecuzione della versione 2.0
import tensorflow as tf
print(tf.__version__)

#crea un tensore
x = [[2.]]
m = tf.square(x)
print("Descrizione di m:",m)
print("Contenuto di m:",m.numpy())
#moltiplica due tensori
a = tf.constant([[2, 2],[3, 4]])
b = tf.constant([[2, 1], #separare le righe aumenta leggibilit�
                 [3, 2]])
ab = tf.matmul(a, b)
print('a * b = \n', ab.numpy())

@tf.function #definisce operazione su tensore
def f(x): return tf.add(x, 1.) #aggiunge 1 a tensore x

a = tf.constant("Benvenuto TensorFlow 2.0!") #tensore con una stringa
print(a)
print(a.numpy())

scalar = tf.constant(1.0) #tensore contiene una costante
vector = tf.constant([1.0, 1.0]) #tensore come array con 2 costanti
matrix = tf.constant([[3.0, 2.0], [6.0, 4.0]]) #tensore come matrice 2x2 con 4 costanti
print(f(scalar))
print(f(vector))
print(f(matrix))

#calcolo del grafo in figura 19.1
a=tf.constant(5)
b=tf.constant(8)
c=tf.constant(2)
d=tf.constant(3)
e=tf.constant(6)
f=((a+b+c)*d)/e
print(f)
print(f.numpy())

#crea un computational graph con i due approcci
import numpy as np
data = np.array([[ 1.764,  0.400],
       [ 0.978,  2.240],
       [ 1.867, -0.977],
       [ 2.467, -0.107]])

input = tf.keras.layers.InputLayer(input_shape=(2)) #input layer con 2 valori
hidden = tf.keras.layers.Dense(3, activation='relu') #1 hidden layer denso con 3 neuroni
output = tf.keras.layers.Dense(1, activation='sigmoid') #output layer denso con 1 neurone
#viene usato Keras per creare il modello e il contenuto delle variabili

#crea modello con approccio di chiamata a funzione ed esecuzione dinamica
#i dati di input vanno nel primo livello, che � il primo nodo
#quando aggiunge il secondo nodo, l'output del primo nodo viene inserito nel secondo nodo
# e viene calcolato l'output del secondo nodo e cos� via
#consente di stampare stati intermedi del modello, ma rallenta molto i calcoli
def model_1(data): 
  x = input(data)
  x = hidden(x)
  print('Dopo il primo layer:', x)
  out = output(x)
  print('Dopo il secondo layer:', out)
  return out

print('Output come tensore:', model_1(data))
print('Output come valori:\n', model_1(data).numpy())

@tf.function  #crea modello con approccio creazione grafo statico
#prima collega tutti i nodi facendo una grande operazione computazionale
#quindi segue il flusso del grafo per fare i calcoli, non mostra stati intermedi 
#del modello n� aggiungere nodi al volo, ma � pi� veloce dell'altro approccio
def model_2(data):
  x = input(data)
  x = hidden(x)
  print('Dopo il primo layer:', x)
  out = output(x)
  print('Dopo il secondo layer:', out)
  return out

print('Output come tensore:', model_2(data))

for i, d in enumerate(data):
    print('batch ciclo esterno {} interno {}:'.format(i,j))
    model_1(d[np.newaxis, :])  # calcola loss con approccio eager

for i, d in enumerate(data):
    print('batch ciclo esterno {} interno {}:'.format(i,j))
    model_2(d[np.newaxis, :]) # calcola loss con approccio grafo statico

import time
start_time = time.time()
c=3
print("--- %s seconds ---" % (time.time() - start_time))

import tensorflow_datasets as tfds
print("Elenco data set in TensorFlow 2.o", tfds.list_builders())
data, info = tfds.load(name='fashion_mnist', as_supervised=True, split=None, with_info=True)
print("Descrizione data set MNIST",info)




#-----------------------------------------------------------------------------------------
#Capitolo 19 Reinforcement learning

#attivare esecuzione con GPU per velocizzare
import gym #importa libreria
env = gym.make("Taxi-v3").env #crea ambiente
env.render()
#mostra ambiente con : strada e | muri, fermate R G Y B, taxi come rettangolo giallo

env.reset() # reset e crea nuovo ambiente
env.render()
print("Spazio azioni {}".format(env.action_space))
print("Spazio stati {}".format(env.observation_space))

stato = env.encode(3, 1, 2, 0) 
# (posizione taxi con riga e colonnataxi row, taxi column, indice passeggero, indice destinazione)
print("Stato:", stato)

env.s = stato
env.render()

print(env.P[328]) #mostra stato in matrice di ricompense P da apprendere con formato stati � azioni 
# formato {azione: [(probabilit�, prossimo stato, ricompensa, lasciato con successo un passeggero oppure no)]}

%%time
#avvia conteggio del tempo esecuzione
#introduce Q-learning consente all'agente di usare le ricompense dell'ambiente per apprendere, 
#nel tempo, le migliori azioni da intraprendere in un determinato stato
#fa qualcosa cercando di ricevere una ricompensa per aver compiuto un'azione nello stato attuale, quindi aggiornando un valore Q per ricordare se quell'azione fosse utile.
import numpy as np
q_table = np.zeros([env.observation_space.n, env.action_space.n]) # formato 500x6
q_table ha  stesse dimensioni della matrice di ricompense P, ma ha scopo completamente diverso
 
import random
from IPython.display import clear_output

# iperparametri in formula per aggiornare q_table
alpha = 0.1; gamma = 0.6; epsilon = 0.1

for i in range(1, 100001):
    stato = env.reset()

    epoche, penalita, ricompensa, = 0, 0, 0;  fatto = False
    
    while not fatto:
        if random.uniform(0, 1) < epsilon:
            azione = env.action_space.sample() # esplora spazio di azioni per cominciare
        else:
            azione = np.argmax(q_table[stato]) # esplora valori gi� appresi
        next_stato, ricompensa, fatto, info = env.step(azione)       
        val_stato = q_table[stato, azione]
        nuovo_max = np.max(q_table[next_stato])       
        nuovo_stato = (1 - alpha) * val_stato + alpha * (ricompensa + gamma * nuovo_max)
        q_table[stato, azione] = nuovo_stato
        if ricompensa == -10:
            penalita += 1
        stato = next_stato;   epoche += 1
        
    if i % 100 == 0:
        clear_output(wait=True)#mostra una riga alla volta con risultato
        print(f"Episodio: {i}")

print("Training finito.\n"); print("Q table: ", q_table[328]); print("Max riga 328", np.max(q_table[328]))
#mostra riga 328 di tabella per notare cambiamento valori
print("Max riga 328", np.max(q_table[328])," posizione ", np.argmax(q_table[328]))

#analisi delle prestazioni
totale_epoche, totale_penalita = 0, 0; episodi = 100
for _ in range(episodi):
    stato = env.reset()
    epoche, penalita, ricompensa = 0, 0, 0
    fatto = False
    while not fatto:
        azione = np.argmax(q_table[stato])
        stato, ricompensa, fatto, info = env.step(azione)
        if ricompensa == -10:
            penalita += 1
        epoche += 1
    totale_penalita += penalita;  totale_epoche += epoche
print(f"Risultato dopo {episodi} episodi:")
print(f"Timestep medio per episodio: {totale_epoche / episodi}")
print(f"Media penalit� per episodio: {totale_penalita / episodi}")

#-----------------------------------------------------------------------------------------
#Capitolo 20

#scaricare da https://github.com/claudiobottari/cnn_vehicle_baseline

#-----------------------------------------------------------------------------------------
#Capitolo 21 Sales forecast
